# newsapp/urls.py
from django.urls import path
from . import views

urlpatterns = [
    path('index.html', views.index, name='index'),  # home page
    path('signup/', views.signup_view, name='signup'),
    path('login/', views.login_view, name='login'),
    path('logout/', views.logout_view, name='logout'),
    path('load_news/', views.load_news, name='load_news'),
    path('feature_selection/', views.run_feature_selection, name='feature_selection'),
    path('train_model/', views.train_model, name='train_model'),
    path('predict/', views.predict_news, name='predict_news'),
]
